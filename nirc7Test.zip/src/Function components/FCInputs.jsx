

import React, { useState } from 'react'

export default function FCInputs() {

  const [ result, setResult ] = useState(0);
  const [ num1, setNum1 ] = useState(0);
  const [ num2, setNum2 ] = useState(0);

  function  btnPlusPress(){
    setResult(parseInt(num1)+parseInt(num2))
  }


  return (
    <div>
      <input onChange={e =>
      setNum1(e.target.value)}>
      
      </input>

      <button onClick={btnPlusPress}>+</button>
      <input onChange={e =>
      setNum2(e.target.value)}>
      
      </input>
      <p>={result}</p>


    </div>
  )
}
