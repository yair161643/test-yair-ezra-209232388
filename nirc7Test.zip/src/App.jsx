import logo from './logo.svg';
import './App.css';
import FCInputs from './Function components/FCInputs';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <FCInputs/>
      </header>
    </div>
  );
}

export default App;
